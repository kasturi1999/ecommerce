import * as React from 'react';
import Login from './components/Login';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Admin from './components/Admin';
import Landingpage from './components/Landingpage';
import AddProduct from './components/AddProduct';
import Dashboard from './components/Dashboard';
import Products from './components/Products';


function App() {
  
  return (
    <>
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<Landingpage/>}/>
      <Route path='/login' element={<Login/>}/>

      <Route path='/admin' element={<Admin/>}>
        <Route path='/admin' element={<Dashboard/>}/>
        <Route path='/admin/product' element={<AddProduct/>}/>
        <Route path='/admin/product/:id' element={<AddProduct/>}/>
        <Route path='/admin/products' element={<Products/>}/>
      </Route>
    </Routes>
    </BrowserRouter>
    
    </>
  )
}

export default App
